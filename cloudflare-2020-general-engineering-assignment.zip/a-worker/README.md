
# General Software Engineering Assignment

  

This is the solution I designed as part of my assignment while applying to be a Software Engineering Intern at Cloudflare. This assignment has been published on my github <github.com/shaungonsalves> and on my cloudflare worker. I would like if you could visit my webpage at <shaungonsalves.github.io> to check out my profile in an attractive website format.

  

## Some Notable Features
 - I have completed all the mandatory and optional requirements as part
   of this assignment.
 - I have included SVG icons from Iconmonstr
   <https://iconmonstr.com/license/> which allows me to use it for this
   assignment.
 - The background is changed to indigo-900 from the tailwind color
   palette.
